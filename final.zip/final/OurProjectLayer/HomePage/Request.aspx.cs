﻿using Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogicLayer;

namespace HomePage
{
    public partial class Request : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["userid"] == null)
            {
                Response.Redirect("HomePagem.aspx");
            }
            UId.Text = Session["userid"].ToString();
            Session["visanumber"] = null;
            Session["user2"] = null;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Retrieve1 bo = new Retrieve1();
            bo.User_Id = UId.Text;
            bo.Passport_Number = PNumber.Text;
            bo.Visa_Number = VNumber.Text;
            bo.Date_Of_Issue = DateTime.Parse(DIssue.Text);
            Retrieve1BO bl = new Retrieve1BO();
            bool s = bl.Authenticate(bo);


            if (s)
            {
                Session["visanumber"] = bo.Visa_Number;
                Session["idt"] = bo.Date_Of_Issue;
                Response.Redirect("Payment.aspx");

            }
            else
            {
                Label1.Text="Entered details mismatched, please enter correct details";
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("MainOfPVCR.aspx");
        }
    }
}
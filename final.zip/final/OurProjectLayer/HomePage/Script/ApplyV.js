﻿function ApplyV()
{
    flag = true;
    str = "";
    var user = document.getElementById("UserId").value;
    if (user.trim().length == 0) {
        flag = false;
        str = str + "\nPlease enter Userid";
    }
    var country = document.getElementById("Country").value;
    if (country == "Select") {
        flag = false;
        str = str + "\n Please select the Country";
        //alert(str);
    }

    var occup = document.getElementById("Occupation").value;
    if (occup == "Select") {
        flag = false;
        str = str + "\n Please select the occupation";
        //alert(str);
    }

    
    if (flag == false) {
        alert(str);
        return flag;
    }
    else {
        return flag;
    }

}
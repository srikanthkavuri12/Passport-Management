﻿function Cancelbutton()
{
    function confirmation() {
        var answer = confirm("Confirm submit?")
        if (answer) {

            window.location = "Cancelbutton.js";// goes to confirmsubmit.jsp
        }
        else {
            alert("nothing");
        }
    }
}
﻿function Reg()
{
    flag = true;
    str = "";
    var cna = document.getElementById("FN").value;
    if (cna.trim().length == 0) {
        flag = false;
        str = str + "Please enter firstname";

    }

    var csr = document.getElementById("SN").value;

    if (csr.trim().length == 0) {
        flag = false;
        str = str + "\nPlease enter surname";
        //alert(str);
    }
    var g = document.getElementById("GEN").value;
    if (g == "select")
    {
        flag = false;
        str = str + "\nPlease select the Gender";
        //alert(str);
    }
    var ml = new RegExp("^[A-Za-z]{1,}@(gmail|outlook|yahoo|hotmail).(com|org|co.in)$");

    var m = document.getElementById("EMAIL").value;

    if (m.trim().length == 0) {
        flag = false;
        str = str + "\nEnter mail id";
        // alert(str);
    }
    else if (!ml.test(m)) {
        flag = false;
        str = str + "\nYour mail_id is invalid, please enter the correct mail_id";
        //alert(str);
    }

    var d = document.getElementById("DOB").value;

    var today = new Date();
    var issuedtae = new Date(d);
    var validity = today.getFullYear() - issuedtae.getFullYear();
    var m = today.getMonth() - issuedtae.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < issuedtae.getDate())) {
        validity = validity - 1;
    }
    if (d == "") {
        flag = false;
        str = str + "\nDate of birth cannot be empty";
        //alert(str);

    }
    var add = document.getElementById("ADD").value;

    if (add.trim().length == 0) {
        flag = false;
        str = str + "\nPlease enter Address";
        //alert(str);
    }
    
    var c = new RegExp("^[0-9]{10}$");
    var cnt = document.getElementById("CNT").value;

    if (cnt.trim().length == 0) {
        flag = false;
        str = str + "\nEnter the contact";
        // alert(str);
    }
    else if (!c.test(cnt)) {
        flag = false;
        str = str + "\nYour contact is invalid, please enter the correct contactnumber";
        //alert(str);
    }
    var at = document.getElementById("AT").value;
    if (at == "select {Passport/Visa}") {
        flag = false;
        str = str + "\nPlease select the Apply Type";
        //alert(str);
    }
    var valid1 = document.getElementById("HQ").value;
    if (valid1 == "Select") {
        flag = false;
        str = str + "\n Please select the hint question";
        //alert(str);
    }
    var ha = document.getElementById("HA").value;

    if (ha.trim().length == 0) {
        flag = false;
        str = str + "\nPlease enter Hint Answer";
        //alert(str);
    }

    if (flag == false)
    {
        alert(str);
        return flag;
    }
    else
    {
        return flag;
    }
}



﻿function LoginV()
{
    flag = true;
    str = "";
    
    var cna = document.getElementById("UD").value;

    if (cna.trim().length == 0) {
        flag = false;
        str = str + "Please enter User-Id";
        //alert(str);
    }
    
    
    var cnp = document.getElementById("PW").value;

    if (cnp.trim().length == 0) {
        flag = false;
        str = str + "\nPlease enter Password";
        //alert(str);
    }
    if (flag == false) {
        alert(str);
        return flag;
    }
    else {
        return flag;
    }
}
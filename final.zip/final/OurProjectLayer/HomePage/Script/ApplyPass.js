﻿function ApplyPass()
{
    flag = true;
    str = "";

    
    var us = document.getElementById("UserId").value;


    if (us.trim().length == 0) {
        flag = false;
        str = str + "\nPlease enter user id";
        //alert(str);
    }
    var c = document.getElementById("Country").value;


    if (c == "Select") {
        flag = false;
        str = str + "\nPlease select the country";
        //alert(str);
    }
    var s = document.getElementById("State").value;


    if (s == "Select") {
        flag = false;
        str = str + "\nPlease select the state";
        //alert(str);
    }
    var city = document.getElementById("City").value;


    if (city == "Select") {
        flag = false;
        str = str + "\nPlease select the city";
        //alert(str);
    }
    var p = document.getElementById("Pin").value;


    if (p.trim().length == 0) {
        flag = false;
        str = str + "\nPlease enter Pin-code";
        //alert(str);
    }
    var ts = document.getElementById("TypeofService").value;


    if (ts == "select") {
        flag = false;
        str = str + "\nPlease select the TypeofService";
        //alert(str);
    }
    var bt = document.getElementById("BookletType").value;


    if (bt == "Select") {
        flag = false;
        str = str + "\nPlease select the BookletType";
        //alert(str);
    }
    //
    if (flag == false) {
        alert(str);
        return flag;
    }
    else {
        return flag;
    }
}
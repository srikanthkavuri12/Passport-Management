﻿function Entry()
{
    flag = true;
    str = "";
    var valid1 = document.getElementById("Hqsn").value;
    if (valid1 == "Select")
    {
        flag = false;
        str = str + "\n Please select the hint question";
        //alert(str);
    }

    /*if (hq.trim().length == 0)
    {
        flag = false;
        str = str + "\nPlease select the hint question";
        alert(str);
    }*/

    var ha = document.getElementById("Hans").value;
    if (ha.trim().length == 0) {
        flag = false;
        str = str + "\nPlease enter answer";
    }
    if (flag == false) {
        alert(str);
        return flag;
    }
    else {
        return flag;
    }

}


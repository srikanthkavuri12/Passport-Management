﻿function Validation() {
    flag = true;
    str = "";

    var r = new RegExp("^VISA-[0-9]{4}$");
    var cno = document.getElementById("UId").value;


    if (cno.trim().length == 0) {
        flag = false;
        str = str + "\nPlease enter user id";
        //alert(str);
    }
    else if (!r.test(cno)) {
        flag = false;
        str = str + "\nYour Id should be as VISA-XXXX";
        //alert(str);
    }
    var p = new RegExp("^FPS-(30|60)[0-9]{4}$");

    var pno = document.getElementById("PNumber").value;

    if (pno.trim().length == 0) {
        flag = false;
        str = str + "\nPassport number should not be empty";
        // alert(str);
    }
    else if (!p.test(pno)) {
        flag = false;
        str = str + "\nYour passport number is invalid, please enter the correct number";
        //alert(str);
    }
    var v = new RegExp("^STU|PE|SE|RE-[0-9]{4}$");
    var vno = document.getElementById("VNumber").value;
    if (vno.trim().length == 0) {
        flag = false;
        str = str + "\nPlease enter VISA number";
        //alert(str);
    }
    else if (!v.test(vno)) {
        flag = false;
        str = str + "\nYour visa number is invalid, please enter the correct number";
        // alert(str);
    }
    var d = document.getElementById("DIssue").value;

    var today = new Date();
    var issuedtae = new Date(d);
    var validity = today.getFullYear() - issuedtae.getFullYear();
    var m = today.getMonth() - issuedtae.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < issuedtae.getDate())) {
        validity = validity - 1;
    }
    if (d == "") {
        flag = false;
        str = str + "\nIssue Date cannot be empty";
        //alert(str);

    }



    else if (vno.includes("STU")) {
        if (validity > 2) {
            flag = false;
            str = str + "\nYour visa was expired, please renew your vis before cancellation ";
            //alert(str);
        }
    }
    else if (vno.includes("PE")) {
        if (validity > 3) {
            flag = false;
            str = str + "\nYour visa was expired, please renew your vis before cancellation ";
            //alert(str);
        }
    }
    else if (vno.includes("GE")) {
        if (validity > 4) {
            flag = false;
            str = str + "\nYour visa was expired, please renew your vis before cancellation ";
            //alert(str);
        }
    }
    else if (vno.includes("SE")) {
        if (validity > 1) {
            flag = false;
            str = str + "\nYour visa was expired, please renew your vis before cancellation ";
            //alert(str);
        }
    }
    else if (vno.includes("RE")) {
        if (validity > 1.5) {
            flag = false;
            str = str + "\nYour visa was expired, please renew your vis before cancellation ";
            //alert(str);
        }
    }

    if (flag == false) {
        alert(str);
        return flag;
    }
    else {
        return flag;
    }

}

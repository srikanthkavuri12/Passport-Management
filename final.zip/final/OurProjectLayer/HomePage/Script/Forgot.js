﻿function Forgot()
{
    flag = true;
    str = "";
    var cna = document.getElementById("HQ").value;

    if (cna == 'select')
    {
        flag = false;
        str = str + "Please Select the Hint Question";
        //alert(str);
    }
    var cnb = document.getElementById("HA").value;

    if (cnb.trim().length == 0) {
        flag = false;
        str = str + "Please enter Hint Answer";
        //alert(str);
    }


   
    var cnn = document.getElementById("NewPW").value;

    if (cnn.trim().length == 0) {
        flag = false;
        str = str + "\nPlease enter New Password";
        //alert(str);
    }
    var cnq = document.getElementById("CPW").value;

    if (cnq.trim().length == 0) {
        flag = false;
        str = str + "\nPlease enter Confirm Password";
        //alert(str);
    }
    var cnn1 = document.getElementById("NewPW").value;
    var cnq1 = document.getElementById("CPW").value;
    if (cnn1 != cnq1)
    {
        str = str + "\nPlease make sure new & old password should be match";
    }

    if (flag == false) {
        alert(str);
        return flag;
    }
    else {
        return flag;
    }
}
﻿using BusinessLogicLayer;
using Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HomePage
{
    public partial class ApplyVisaM : System.Web.UI.Page
    {
        VisaBo c = new VisaBo();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["userid"] == null)
            {
                Response.Redirect("HomePageM.aspx");
            }
            try
            {
                UserId.Text = Session["userid"].ToString();

                
            }
            catch (NullReferenceException)
            {
                Response.Write("<script>alert('Please login and try again')</script>");
            }

            //Here we are retrieving country info.
            if (!IsPostBack)
            {
                List<Country> L = c.PopulateCountry();
                Country.DataSource = L;
                Country.DataTextField = "Country_Name";
                Country.DataValueField = "Country_Id";
                Country.DataBind();

                List<Occupation> L1 = c.PopulateOccupation();
                Occupation.DataSource = L1;
                Occupation.DataTextField = "Occupation_Name";
                Occupation.DataValueField = "Occupation_Id";
                Occupation.DataBind();

            }
        }
        //If we press the submit button the form details will be send to other layer
        protected void Button2_Click(object sender, EventArgs e)
        {
            Visa C = new Visa();
            C.Userid = Session["userid"].ToString();
            C.Countryname = Country.Text;
            C.Occupationname = Occupation.SelectedValue;
            VisaBo CC = new VisaBo();
            string s = CC.InsertDetails2(C);

            
            Label1.Text = s;
            //Response.Write(cost);
            Response.Write("<script>alert('" + s + "')</script>");

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("MainOfPVCR.aspx");
        }
    }
}
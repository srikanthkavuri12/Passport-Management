﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HomePage
{
    public partial class Payment : System.Web.UI.Page
    {
        string s1 = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            string vn = Session["visanumber"].ToString();
            DateTime d1 = DateTime.Parse(Session["idt"].ToString());
            DateTime d2 = DateTime.Now;
            double d = (double)d2.Subtract(d1).TotalDays / (365.25 / 12);


            if (vn.Contains("STU"))
            {
                if (d < 6)
                {
                    s1 = "Your request has beem submitted successfully. Please pay 1049 to complete the cancellation";
                }
                if (d > 6)
                {
                    s1 = "Your request has beem submitted successfully. Please pay 1499 to complete the cancellation";
                }
            }
            else if (vn.Contains("PE"))
            {
                if (d < 6)
                {
                    s1 = "Your request has beem submitted successfully. Please pay 1499 to complete the cancellation";
                }
                else if (d >= 6 && d < 12)
                {
                    s1 = "Your request has beem submitted successfully. Please pay 1999 to complete the cancellation";
                }
                else if (d >= 12)
                {
                    s1 = "Your request has beem submitted successfully. Please pay 2599 to complete the cancellation";
                }
            }
            else if (vn.Contains("GE"))
            {
                if (d < 6)
                {
                    s1 = "Your request has beem submitted successfully. Please pay 749 to complete the cancellation";
                }
                else if (d >= 6 && d < 12)
                {
                    s1 = "Your request has beem submitted successfully. Please pay 1049 to complete the cancellation";
                }
                else if (d >= 12)
                {
                    s1 = "Your request has beem submitted successfully. Please pay 1299 to complete the cancellation";
                }
            }
            else if (vn.Contains("SE"))
            {
                if (d < 6)
                {
                    s1 = "Your request has beem submitted successfully. Please pay 999 to complete the cancellation";
                }
                else if (d >= 6 && d < 12)
                {
                    s1 = "Your request has beem submitted successfully. Please pay 1299 to complete the cancellation";
                }
                else if (d >= 12)
                {
                    s1 = "Your request has beem submitted successfully. Please pay 1799 to complete the cancellation";
                }
            }
            else if (vn.Contains("RE"))
            {
                if (d < 6)
                {
                    s1 = "Your request has beem submitted successfully. Please pay 749 to complete the cancellation";
                }
                else if (d >= 6)
                {
                    s1 = "Your request has beem submitted successfully. Please pay 999 to complete the cancellation";
                    
                }
            }

            Label1.Text = s1;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("UpdateCancel.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("MainOfPVCR.aspx");
        }
    }
}
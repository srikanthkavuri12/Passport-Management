﻿using BusinessLogicLayer;
using Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HomePage
{
    public partial class HintQsn : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }       

        protected void Button4_Click(object sender, EventArgs e)
        {
            Retrieve2 bo = new Retrieve2();


            if (Session["userid"] != null)
            {
                bo.UserId = Session["userid"].ToString();
            }
            bo.hint_ques = Hqsn.Text;
            bo.hint_ans = Hans.Text;


            RetrieveBO2 b2 = new RetrieveBO2();


            bool s = b2.QAuthenticate(bo);
            if (s)
            {
                Response.Redirect("Request.aspx");
            }
            else
            {
                Response.Write("Your details mismatched, please enter correct details");
            }
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("MainOfPVCR.aspx");
        }

        
    }
}
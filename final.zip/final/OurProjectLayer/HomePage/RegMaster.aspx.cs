﻿using BusinessLogicLayer;
using Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HomePage
{
    public partial class RegMaster : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //In classes it goes to Businees.cs file to assign the values.
        protected void Button1_Click(object sender, EventArgs e)
        {
            Businees c = new Businees();

            c.first_name = FN.Text;
            c.sur_name = SN.Text;
            c.gender = GEN.Text;
            c.email = EMAIL.Text;
            try
            {
                c.dob = DateTime.Parse(DOB.Text);
            }
            catch(FormatException)
            {
                Response.Write("<script>alert('Date can't be blank')</script>");
            }
            c.address = ADD.Text;
            c.contact_no = CNT.Text;
            c.apply_type = AT.Text;
            c.hint_q = HQ.Text;
            c.hint_a = HA.Text;


            BusinessBO CS = new BusinessBO();
            string s3 = CS.InsertCustomer(c);
            // It is used to find the Age type
            if (s3 != null)
            {

                int age = 0;
                age = DateTime.Now.Year - c.dob.Year;
                if (DateTime.Now.DayOfYear < c.dob.DayOfYear)
                {
                    age = age - 1;
                }
                string A = null;
                if (age == 0 || age == 1)
                    A = "Infant";
                else if (age > 1 && age < 10)
                    A = "Children";
                else if (age >= 10 && age < 20)
                    A = "Teen";
                else if (age >= 20 && age < 50)
                    A = "adult";
                else if (age >= 50)
                    A = "Senior Citizen";

                if (s3.Contains("email already registered"))
                {
                    Response.Write("<script>alert('" + s3 + "')</script>");
                }
                else
                {
                    Label1.Text = s3 + " You are planning for " + c.apply_type + " Your Citizen type is " + A;
                }
            }
            else
            {
                Response.Write("Check your Details something went wrong");
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);
        }

        
    }
}
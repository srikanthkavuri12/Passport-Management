﻿using BusinessLogicLayer;
using Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HomePage
{
    public partial class PassportReissue : System.Web.UI.Page
    {
        Reissuebo C = new Reissuebo();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["userid"] == null)
            {
                Response.Redirect("HomePageM.aspx");
            }
            else
            {
                Userid.Text = Session["Userid"].ToString();
            }
            //Here we are checking whether the page is refereshed one or more time
            if (!IsPostBack)
            {
                //Here we are assigning values to dropdown list from database
                List<Country> L = C.PopulateCountry();
                Country.DataSource = L;
                Country.DataTextField = "Country_Name";
                Country.DataValueField = "Country_Id";
                Country.DataBind();
            }
        }
        //Here we are assigning values to dropdown list from database
        protected void State_SelectedIndexChanged1(object sender, EventArgs e)
        {
            City.Items.Clear();
            City.Items.Add("Select");
            List<City> Ci = C.PopulateCity(State.SelectedValue);
            City.DataSource = Ci;
            City.DataTextField = "City_Name";
            City.DataValueField = "City_Id";
            City.DataBind();
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            //on button click event
            Reissue C = new Reissue();
            C.Reasonforreissue = Reasonforreissue.Text.ToString();
            C.UserID = Userid.Text.ToString();
            C.Country = Country.Text;
            C.state = State.Text;
            C.city = City.Text;
            
            double d;
            if (Typeofservice.Text == "Normal")
            {
                C.TypeofServiceid = 1;
                d = 2500;
            }
            else
            {
                C.TypeofServiceid = 2;
                d = 5000;
            }

            if (Booklettype.Text == "30 Pages")
            {
                C.Booklettypeid = 1;

            }
            else if (Booklettype.Text == "60 Pages")
            {
                C.Booklettypeid = 2;

            }

            Reissuebo CC = new Reissuebo();
            string s = CC.InsertDetails(C);

            if (s.Contains("Register and then apply"))
            {
                Label1.Text = s;
            }
            else if (s.Contains("Cannot have duplicate Customer"))
            {
                Label1.Text = s;
            }
            else
            {
                Label1.Text = "Need the passport number while giving payment? Please note down your Id " + s + " Passport application cost is Rs  = " + d;
            }
            Response.Write("<script>alert('" + s + "')</script>");
            
        }

        protected void Country_SelectedIndexChanged1(object sender, EventArgs e)
        {
            State.Items.Clear();
            State.Items.Add("Select");
            //Here we are assigning values to dropdown list from database
            List<State> S = C.PopulateSate(Country.SelectedValue);
            State.DataSource = S;
            State.DataTextField = "State_Name";
            State.DataValueField = "State_Id";
            State.DataBind();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            //For redirecting to main page 
            Response.Redirect("MainOfPVCR.aspx");
        }
    }
}
﻿using BusinessLogicLayer;
using Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HomePage
{
    public partial class LoginMaster : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Log L = new Log();
            L.username = UD.Text;
            L.pwd = PW.Text;
            LoginBo LB = new LoginBo();
            bool b = LB.LoginValidate(L);
            if (b)
            {

                Session["userid"] = L.username;
                Response.Redirect("MainOfPVCR.aspx");
            }
            else
            {
                Label1.Text = "Invalid Username/Password...";
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePageM.aspx");
        }

        
    }
}
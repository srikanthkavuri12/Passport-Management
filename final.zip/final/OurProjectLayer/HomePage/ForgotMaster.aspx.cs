﻿using BusinessLogicLayer;
using Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HomePage
{
    public partial class ForgotMaster : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePageM.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ForgotBo b = new ForgotBo();
            Businees bu = new Businees();
            Forgot b1 = new Forgot();

            try
            {
                b1.Hintq = HQ.Text;
                b1.answ = HA.Text;
                b1.UserId = UserID.Text;
                b1.newpass = NewPW.Text;
            }
            catch (Exception )
            {
                Response.Write("Password doesnt match");
            }
            

            b.forgotdetails(b1);

            Label1.Text = "Successful";
        }
    }
}
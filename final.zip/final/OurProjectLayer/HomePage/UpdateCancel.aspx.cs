﻿using Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HomePage
{
    public partial class UpdateCancel : System.Web.UI.Page
    {
        Retrieve1 r = new Retrieve1();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["userid"]==null)
            {
                Response.Redirect("HomePageM.aspx");
            }
            string s = "Your visa cancelled successfully";
            
            Label1.Text = s;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("MainOfPVCR.aspx");
        }
    }
}
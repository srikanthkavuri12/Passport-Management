﻿using BusinessLogicLayer;
using Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HomePage
{
    public partial class Contact : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ContactDetails d = new ContactDetails();
            
            d.firstname = CFN.Text;
            d.surname = CSN.Text;
            d.email_id = CEM.Text;
            d.contact = CCNT.Text;
            d.message_type = CM.Text;      
          


            ContactBO CS = new ContactBO();
            string s = CS.InsertCustomer(d);
            Response.Write("<script>'"+s+"'</script>");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePageM.aspx");
        }
    }
}   
﻿using BusinessLogicLayer;
using Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HomePage
{
    public partial class Applypassportform : System.Web.UI.Page
    {
        PassportBO C = new PassportBO();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["userid"] == null)
            {
                Response.Redirect("HomePageM.aspx");
            }
            try
            {
                UserId.Text = Session["userid"].ToString();
                if(Session["userid"]==null)
                {
                    Response.Redirect("HomePageM.aspx");
                }
            }
            catch(NullReferenceException)
            {
                Response.Write("<script>alert('Please login and try again')</script>");
            }
            //Here we are retrieving country info. 
            if (!IsPostBack)
            {
                List<Country> L = C.PopulateCountry();
                Country.DataSource = L;
                Country.DataTextField = "Country_Name";
                Country.DataValueField = "Country_Id";
                Country.DataBind();

            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Class1 C = new Class1();


            C.UserID = Session["userid"].ToString();
            C.Country = Country.Text;
            C.state = State.Text;
            C.city = City.Text;
            try
            {
                C.Pin = int.Parse(Pin.Text.ToString());
            }
            catch (FormatException)
            {
                Response.Write("<script>alert('Pin cannot be empty')</script>");
            }
            double d;
            if (TypeofService.Text == "Normal")
            {
                C.TypeofServiceid = 1;
                d = 2500;
            }
            else
            {
                C.TypeofServiceid = 2;
                d = 5000;
            }

            if (BookletType.Text == "30 pages")
            {
                C.Booklettypeid = 1;

            }
            else if (BookletType.Text == "60 pages")
            {
                C.Booklettypeid = 2;

            }

            PassportBO CC = new PassportBO();
            string s = CC.InsertDetails(C);
            if (s.Contains("Cannot have duplicate Customer"))
            {
                Response.Write("<script>alert('" + s + "')</script>");
            }
            else
            {
            string status="Need the passport number while giving payment? Please note down your Id " + s + " Passport application cost is Rs " + d;
            Status.Text = status;
            Response.Write("<script>alert('" + s + "')</script>");
            }
        }

        protected void Country_SelectedIndexChanged(object sender, EventArgs e)
        {
            State.Items.Clear();
            State.Items.Add("Select");
            List<State> S = C.PopulateSate(Country.SelectedValue);
            State.DataSource = S;
            State.DataTextField = "State_Name";
            State.DataValueField = "State_Id";
            State.DataBind();
        }

        protected void State_SelectedIndexChanged(object sender, EventArgs e)
        {
            City.Items.Clear();
            City.Items.Add("Select");
            List<City> Ci = C.PopulateCity(State.SelectedValue);
            City.DataSource = Ci;
            City.DataTextField = "City_Name";
            City.DataValueField = "City_Id";
            City.DataBind();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("MainOfPVCR.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('Payment Successful')</script>");
        }
    }
}
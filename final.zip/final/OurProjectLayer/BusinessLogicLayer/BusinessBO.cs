﻿using Classes;
using DataLogicLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    // In BusinessBo file we create a object of Businees class.
    public class BusinessBO
    {
        SqlParameter P = null;
        public string InsertCustomer(Businees C)
        {
            string date = null;
            string num = DBOperations.getCustId1(C.apply_type.Substring(0, 4));
            // Generating the Password here.
            DateTime D1 = DateTime.Now;
            string dd = D1.ToString("dd");
            string MM = D1.ToString("MMM");
            Random random = new Random();
            int value = random.Next(1000);
            if (int.Parse(num) % 2 == 0)
            {
                date = dd.ToString() + MM.ToString() + "@" + value;
            }
            else
            {
                date = dd.ToString() + MM.ToString() + "#" + value;
            }
            // Here we are send the values to the List
            List<SqlParameter> L = new List<SqlParameter>();
            P = new SqlParameter("@Customer_id", C.apply_type.Substring(0, 4)+"-"+num);
            L.Add(P);
            P = new SqlParameter("@First_name", C.first_name);
            L.Add(P);
            P = new SqlParameter("@Sur_name", C.sur_name);
            L.Add(P);
            P = new SqlParameter("@Gender", C.gender);
            L.Add(P);
            P = new SqlParameter("@EMAIL_id", C.email);
            L.Add(P);
            P = new SqlParameter("@DOB", C.dob);
            L.Add(P);
            P = new SqlParameter("@Address", C.address);
            L.Add(P);
            P = new SqlParameter("@Contact_Number", C.contact_no);
            L.Add(P);
            P = new SqlParameter("@Apply_type", C.apply_type);
            L.Add(P);
            P = new SqlParameter("@Hint_Question", C.hint_q);
            L.Add(P);
            P = new SqlParameter("@Hint_Answer", C.hint_a);
            L.Add(P);
            P = new SqlParameter("@Password", date);
            L.Add(P);
            P = new SqlParameter("@st", SqlDbType.NVarChar, 50);
            P.Direction = ParameterDirection.Output;
            L.Add(P);
            //Here it calls DBOperation class to send the List values to Storedprocedure
            string s1 = DBOperations.ExecuteInsert("sp_insert", L);
            return s1;
        }
    }
}

﻿using Classes;
using DataLogicLayer;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BusinessLogicLayer
{
     public class CustomerLoginBo
    {
        static SqlParameter p = null;
        public string login(customerlogin c)
        {
            List<SqlParameter> l = new List<SqlParameter>();
            p = new SqlParameter("@email", c.Username);
            l.Add(p);
            p = new SqlParameter("@password", c.Password);
            l.Add(p);
            string s = DBOperations.login(l);
            return s;
        }

    }
}

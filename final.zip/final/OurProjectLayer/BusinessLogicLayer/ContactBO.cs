﻿using Classes;
using DataLogicLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BusinessLogicLayer
{
    public class ContactBO
    {
        SqlParameter P = null;
        public string InsertCustomer(ContactDetails C)
        {
            List<SqlParameter> L = new List<SqlParameter>();
            P = new SqlParameter("@firstname", C.firstname);
            L.Add(P);
            P = new SqlParameter("@surname", C.surname);
            L.Add(P);
            P = new SqlParameter("@email", C.email_id);
            L.Add(P);
            P = new SqlParameter("@contact", C.contact);
            L.Add(P);
            P = new SqlParameter("@message_type", C.message_type);
            L.Add(P);
            
            P = new SqlParameter("@st", SqlDbType.NVarChar, 50);
            P.Direction = ParameterDirection.Output;
            L.Add(P);
            string s = DBOperations.ExecuteInsert("sp_contact", L);
            return s;
        }
    }
}

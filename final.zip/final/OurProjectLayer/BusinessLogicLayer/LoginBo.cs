﻿using Classes;
using DataLogicLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    public class LoginBo
    {
        SqlParameter P = null;


        public bool LoginValidate(Log L)
        {
            List<SqlParameter> L1 = new List<SqlParameter>();
            SqlParameter P = null;
            P = new SqlParameter("@username", L.username);
            L1.Add(P);
            P = new SqlParameter("@password", L.pwd);
            L1.Add(P);
            bool B = DBOperations.loginValidate("sp_LoginValidate", L1);
            return B;
        }

    }
}


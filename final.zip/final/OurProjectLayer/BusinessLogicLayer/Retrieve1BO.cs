﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Classes;
using DataLogicLayer;


namespace BusinessLogicLayer
{
    public class Retrieve1BO
    {

        SqlParameter P = null;
        public bool Authenticate(Retrieve1 R)
        {
            List<SqlParameter> l = new List<SqlParameter>();
            P = new SqlParameter("@user_Id", R.User_Id);
            l.Add(P);
            P = new SqlParameter("@passport_id", R.Passport_Number);
            l.Add(P);
            P = new SqlParameter("@visa_id", R.Visa_Number);
            l.Add(P);
            P = new SqlParameter("@doi", R.Date_Of_Issue);
            l.Add(P);
            
            //P = new SqlParameter("@amount", 400);
            //l.Add(P);

            bool s = DBOperations.ExecuteAuthenticate("SP_Cancellation", l);
            return s;
        }
    }
}
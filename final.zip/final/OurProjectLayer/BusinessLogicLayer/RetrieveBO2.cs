﻿using Classes;
using DataLogicLayer;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    public class RetrieveBO2
    {
        SqlParameter Q = null;
        public bool QAuthenticate(Retrieve2 R1)
        {
            List<SqlParameter> L = new List<SqlParameter>();
           
            Q = new SqlParameter("@hint_qsn", R1.hint_ques);
            L.Add(Q);
            Q = new SqlParameter("@hint_ans", R1.hint_ans);
            L.Add(Q);

            bool s = DBOperations.ExecuteQAuthenticate("SP_HVALIDATE", L);
            return s;
        }
    }
}


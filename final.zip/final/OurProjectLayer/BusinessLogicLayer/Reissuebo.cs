﻿using Classes;
using DataLogicLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    public class Reissuebo
    {
        SqlParameter P = null;
        public string InsertDetails(Reissue C)
        {
            //Here we are generating passport Id,generating dateOfissue & expiry date 
            List<SqlParameter> L = new List<SqlParameter>();
            int c = DBOperations.getcustid();
            string cid;
            if (C.Booklettypeid == 1)
            {
                cid = "FPS-30" + c.ToString("0000");
            }
            else if (C.Booklettypeid == 2)
            {
                cid = "FPS-60" + c.ToString("0000");
            }
            else
            {
                cid = c.ToString("0");
            }
            DateTime dt = DateTime.Now;



            DateTime theDate = DateTime.Now;
            DateTime yearInTheFuture = theDate.AddYears(10);

            //Here we are inserting values to database
            P = new SqlParameter("@Reason", C.Reasonforreissue);
            L.Add(P);
            P = new SqlParameter("@Customer_id", C.UserID);
            L.Add(P);
            P = new SqlParameter("@Country_id", C.Country);
            L.Add(P);
            P = new SqlParameter("@State_id", C.state);
            L.Add(P);
            P = new SqlParameter("@City_id", C.city);
            L.Add(P);
            P = new SqlParameter("@Service_id", C.TypeofServiceid);
            L.Add(P);
            P = new SqlParameter("@Booklet_Id", C.Booklettypeid);
            L.Add(P);

            P = new SqlParameter("@Issue_Date", dt);
            L.Add(P);
            P = new SqlParameter("@Expiry_Date", yearInTheFuture);
            L.Add(P);
            P = new SqlParameter("@Passport_Number", cid);
            L.Add(P);
            P = new SqlParameter("@st", SqlDbType.NVarChar, 50);
            P.Direction = ParameterDirection.Output;
            L.Add(P);
            string s = DBOperations.ExecuteInsert("Sp_reissue", L);
            return s;
        }
        //Here we are creating list of countries
        public List<Country> PopulateCountry()
        {
            List<Country> L = DBOperations.populateCountry();


            return L;
        }
        //Here we are creating list of State
        public List<State> PopulateSate(string cname)
        {
            List<State> S = DBOperations.PopulateState(cname);
            return S;
        }
        //Here we are creating list of City
        public List<City> PopulateCity(string Ciname)
        {
            List<City> Ci = DBOperations.PopulateCity(Ciname);
            return Ci;
        }
    }
}

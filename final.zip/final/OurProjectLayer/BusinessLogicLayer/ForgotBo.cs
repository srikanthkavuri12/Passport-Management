﻿using Classes;
using DataLogicLayer;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    public class ForgotBo
    {
        SqlParameter P = null;
        public string forgotdetails(Forgot C)
        {
            List<SqlParameter> L = new List<SqlParameter>();
            P = new SqlParameter("@user_id", C.UserId);
            L.Add(P);
            P = new SqlParameter("@newpass",C.newpass);
            L.Add(P);
            P = new SqlParameter("@Confirmpass", C.newpass);
            L.Add(P);
            P = new SqlParameter("@hint_question",C.Hintq);
            L.Add(P);
            P = new SqlParameter("@hint_answer", C.answ);
            L.Add(P);

            string s = DBOperations.ExecuteInsert("Sp_updatepass", L);
            return s;
        }
    }
}

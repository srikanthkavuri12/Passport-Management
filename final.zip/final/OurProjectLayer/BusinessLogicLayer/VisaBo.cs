﻿using Classes;
using DataLogicLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    public class VisaBo
    {
        SqlParameter P = null;
        public string InsertDetails2(Visa C)
        {
            List<SqlParameter> L = new List<SqlParameter>();
            double expr = 0;
            int c = DBOperations.getcustid();
            string visa = null;
            int cost = 0;
           
            if (C.Occupationname == "1")
            {
                visa = "STU" + c.ToString("0000");
                expr = 2;
            }
            else if (C.Occupationname == "2")
            {
                visa = "PE" + c.ToString("0000");
                expr = 3;
            }
            else if (C.Occupationname == "3")
            {
                visa = "GE" + c.ToString("0000");
                expr = 4;
            }
            else if (C.Occupationname == "4")
            {
                visa = "SE" + c.ToString("0000");
                expr = 1;
            }
            else if (C.Occupationname == "5")
            {
                visa = "RE" + c.ToString("0000");
                expr = 1.5;
            }





           


           
            if (C.Occupationname == "1")
            {
                if (C.Countryname == "6")
                {
                    cost = 3000;
                }
                else if (C.Countryname == "7")
                {
                    cost = 1500;
                }
                else if (C.Countryname == "8")
                {
                    cost = 3500;
                }
                else if (C.Countryname == "1")
                {
                    cost = 1000;
                }
                else if (C.Countryname == "2")
                {
                    cost = 1200;
                }
                else if (C.Countryname == "3")
                {
                    cost = 1300;
                }
                else if (C.Countryname == "4")
                {
                    cost = 1400;
                }
                else if(C.Countryname=="5")
                {
                    cost = 1500;
                }
            }
            else if (C.Occupationname == "2")
            {
                if (C.Countryname == "6")
                {
                    cost = 4500;
                }
                else if (C.Countryname == "7")
                {
                    cost = 2000;
                }
                else if (C.Countryname == "8")
                {
                    cost = 4000;
                }
                else if (C.Countryname == "1")
                {
                    cost = 1000;
                }
                else if (C.Countryname == "2")
                {
                    cost = 1200;
                }
                else if (C.Countryname == "3")
                {
                    cost = 1300;
                }
                else if (C.Countryname == "4")
                {
                    cost = 1400;
                }
                else if (C.Countryname == "5")
                {
                    cost = 1500;
                }
            }
            else if (C.Occupationname == "3")
            {
                if (C.Countryname == "6")
                {
                    cost = 5000;
                }
                else if (C.Countryname == "7")
                {
                    cost = 3000;
                }
                else if (C.Countryname == "8")
                {
                    cost = 4500;
                }
                else if (C.Countryname == "1")
                {
                    cost = 5000;
                }
                else if (C.Countryname == "1")
                {
                    cost = 1000;
                }
                else if (C.Countryname == "2")
                {
                    cost = 1200;
                }
                else if (C.Countryname == "3")
                {
                    cost = 1300;
                }
                else if (C.Countryname == "4")
                {
                    cost = 1400;
                }
                else if (C.Countryname == "5")
                {
                    cost = 1500;
                }
            }
            else if (C.Occupationname == "4")
            {
                if (C.Countryname == "6")
                {
                    cost = 6000;
                }
                else if (C.Countryname == "7")
                {
                    cost = 4000;
                }
                else if (C.Countryname == "8")
                {
                    cost = 9000;
                }
                else if (C.Countryname == "1")
                {
                    cost = 1000;
                }
                else if (C.Countryname == "2")
                {
                    cost = 1200;
                }
                else if (C.Countryname == "3")
                {
                    cost = 1300;
                }
                else if (C.Countryname == "4")
                {
                    cost = 1400;
                }
                else if (C.Countryname == "5")
                {
                    cost = 1500;
                }
            }
            else if (C.Occupationname == "5")
            {
                if (C.Countryname == "6")
                {
                    cost = 2000;
                }
                else if (C.Countryname == "7")
                {
                    cost = 2000;
                }
                else if (C.Countryname == "8")
                {
                    cost = 1000;
                }
                else if (C.Countryname == "1")
                {
                    cost = 1000;
                }
                else if (C.Countryname == "2")
                {
                    cost = 1200;
                }
                else if (C.Countryname == "3")
                {
                    cost = 1300;
                }
                else if (C.Countryname == "4")
                {
                    cost = 1400;
                }
                else if (C.Countryname == "5")
                {
                    cost = 1500;
                }
            }
           


            DateTime dt = DateTime.Now;
            DateTime theDate = DateTime.Now;
            DateTime dayInTheFuture = theDate.AddDays(10);

            P = new SqlParameter("@User_id", C.Userid);
            L.Add(P);
            P = new SqlParameter("@Country_id", C.Countryname);
            L.Add(P);
            P = new SqlParameter("@Occupation_id", C.Occupationname);
            L.Add(P);
            P = new SqlParameter("@dateofapplication", dt);
            L.Add(P);
            //P = new SqlParameter("@Passport_Number", C.Passport_Number);
            //L.Add(P);
            P = new SqlParameter("@visa_id", visa);
           
            L.Add(P);
            P = new SqlParameter("@date_of_issue", dayInTheFuture);  //here we are generating date of issue
            L.Add(P);

            P = new SqlParameter("@date_of_expiry", expr);   //here we are generating the date of expiary according to the occupation
            L.Add(P);
            
            P=new SqlParameter("@registration_cost",cost);   //here we are generating the cost for visa according to the occupation and country
            L.Add(P);

            P = new SqlParameter("@st", SqlDbType.NVarChar, 50);
            P.Direction = ParameterDirection.Output;
            L.Add(P);

            string s = DBOperations.ExecuteInsert2("Sp_ApplyVisa", L);  
            return s;
        }

        //creating list of occupation from database
        public List<Occupation> PopulateOccupation()
        {
            List<Occupation> L = DBOperations.PopulateOccupation();

            return L;
        }

        //creating list of country from database
        public List<Country> PopulateCountry()
        {
            List<Country> L = DBOperations.populateCountry();


            return L;
        }

    }
}

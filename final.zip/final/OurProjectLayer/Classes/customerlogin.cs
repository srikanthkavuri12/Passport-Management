﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class customerlogin
    {
        string username;

        public string Username
        {
            get { return username; }
            set { username = value; }
        }
        string password;

        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        public customerlogin(string a, string b)
        {
            this.username = a;
            this.password = b;
        }

        public customerlogin()
        {
            // TODO: Complete member initialization
        }
    }
}

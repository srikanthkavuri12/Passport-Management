﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Retrieve1
    {
        public string User_Id { set; get; }
        public string Passport_Number { set; get; }
        public string Visa_Number { set; get; }
        public DateTime Date_Of_Issue { set; get; }
        //public int amount { set; get; }
    }
}

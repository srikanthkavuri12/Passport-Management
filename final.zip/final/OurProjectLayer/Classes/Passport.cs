﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Passport
    {
        public string UserID { set; get; }
        public string Country { set; get; }
        public string state { set; get; }
        public string city { set; get; }
        public int Pin { set; get; }
        public int TypeofServiceid { set; get; }
        public int Booklettypeid { set; get; }
        public DateTime IssueDate { set; get; }
        public DateTime ExpiryDate { set; get; }
    }
}

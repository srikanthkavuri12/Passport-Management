﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Log
    {
        public string username { set; get; }
        public string pwd { set; get; }
        public string contact_no { set; get; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class ContactDetails
    {
        public string firstname { set; get; }
        public string surname { set; get; }
        public string email_id { set; get; }
        public string contact { set; get; }
        public string message_type { set; get; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class State
    {
        public string State_id { set; get; }
        public string State_Name { set; get; }
        public string Country_id { set; get; }
    }
}

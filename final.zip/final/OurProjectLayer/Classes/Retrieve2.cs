﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Retrieve2
    {
        public string UserId { set; get; }
        public string hint_ques { set; get; }
        public string hint_ans { set; get; }
    }
}

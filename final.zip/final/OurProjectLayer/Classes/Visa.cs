﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Visa
    {
        public string Userid { set; get; }
        public string Countryname { set; get; }
        public string Occupationname { set; get; }
        public DateTime ApplyDate { set; get; }

        public double ExpiryDate { set; get; }
        public string VisaNumber { set; get; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Forgot
    {
        public string UserId { set; get; }
        public string Hintq { set; get; }
        public string answ { set; get; }
        public string oldpass { set; get; }
        public string newpass { set; get; }
        public string confnewpass { set; get; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Businees
    {
        public int c_id { set; get; }
        public string first_name { set; get; }
        public string sur_name { set; get; }
        public string email { set; get; }
        public string gender { set; get; }
        public DateTime dob { set; get; }
        public string address { set; get; }
        public string contact_no { set; get; }
        public string apply_type { set; get; }
        public string hint_q { set; get; }
        public string hint_a { set; get; }


    }
}

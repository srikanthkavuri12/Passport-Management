﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class City
    {
        public string City_id { set; get; }
        public string City_Name { set; get; }
        public string State_id { set; get; }
    }
}

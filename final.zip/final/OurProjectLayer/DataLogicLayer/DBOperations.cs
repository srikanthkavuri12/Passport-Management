﻿using Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLogicLayer
{
    public class DBOperations
    {
        static SqlConnection C = new SqlConnection(DBConnections.getConnection());
        static SqlCommand Cmd = null;
        public DBOperations()
        {


        }
        // Registration part
        // Here we excute the Query to call the database
        public static string ExecuteInsert1(string spname, List<SqlParameter> L)
        {
            string s3 = null;
            try
            {
                C.Open();
                Cmd = new SqlCommand(spname, C);
                Cmd.CommandType = CommandType.StoredProcedure;
                //sending to database
                foreach (SqlParameter P in L)
                {
                    Cmd.Parameters.Add(P);
                }
                int n = Cmd.ExecuteNonQuery();


                string s1 = null;
                string s2 = null;
                if (n == 1)
                {
                    s1 = L[0].Value.ToString();
                    s2 = L[11].Value.ToString();
                    s3 = "User-Id =" + s1 + "\nPassword =" + s2;
                }
                else
                {
                    s3 = null;
                }

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                C.Close();
            }
        
            return s3;
        }
        public static bool ExecuteAuthenticate(string spname, List<SqlParameter> l)
        {
            bool Flag = false;
            try
            {
                C.Open();
                Cmd = new SqlCommand(spname, C);
                Cmd.CommandType = CommandType.StoredProcedure;
                foreach (SqlParameter p in l)
                {
                    Cmd.Parameters.Add(p);
                }

                SqlDataReader R = Cmd.ExecuteReader();

                if (R.Read())
                    Flag = true;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                C.Close();
            }
            return Flag;
        }
        public static bool ExecuteQAuthenticate(string spname, List<SqlParameter> L)
        {
            bool Flag = false;
            try
            {
                C.Open();
                Cmd = new SqlCommand(spname, C);
                Cmd.CommandType = CommandType.StoredProcedure;
                foreach (SqlParameter p in L)
                {
                    Cmd.Parameters.Add(p);
                }

                SqlDataReader R = Cmd.ExecuteReader();
                if (R.Read())
                    Flag = true;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                C.Close();
            }
            return Flag;
        }
        
        
        public static string ExecuteInsert(string spname, List<SqlParameter> l)
        {
            try
            {
                C.Open();
                Cmd = new SqlCommand(spname, C);
                Cmd.CommandType = CommandType.StoredProcedure;
                foreach (SqlParameter sp in l)
                {
                    Cmd.Parameters.Add(sp);
                }
                Cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {

                C.Close();
            }
            // Getting the Status of the Registration
            return l[l.Count - 1].Value.ToString();
        }

        
        public static List<Country> populateCountry()
        {
            List<Country> L = new List<Country>();
            try
            {
                C.Open();
                Cmd = new SqlCommand("sp_country", C);
                Cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader R = Cmd.ExecuteReader();

                Country C1 = null;
                while (R.Read())
                {
                    C1 = new Country();
                    C1.Country_Id = R[0].ToString();
                    C1.Country_Name = R[1].ToString();
                    L.Add(C1);

                }
            }
            catch (Exception e)
            {
                throw e;
            }

            finally
            {
                C.Close();
            }
            return L;



        }
        public static List<State> PopulateState(string Cname)
        {
            List<State> L = new List<State>();
            try
            {
                C.Open();
                Cmd = new SqlCommand("Sp_state", C);

                Cmd.CommandType = CommandType.StoredProcedure;
                Cmd.Parameters.AddWithValue("@cname", Cname);
                SqlDataReader R1 = Cmd.ExecuteReader();
                State S = null;

                while (R1.Read())
                {
                    S = new State();
                    S.State_id = R1[0].ToString();
                    S.State_Name = R1[1].ToString();
                    L.Add(S);

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                C.Close();
            }
            return L;

        }

        public static List<City> PopulateCity(string Ciname)
        {
            List<City> L = new List<City>();
            try
            {
                C.Open();
                Cmd = new SqlCommand("Sp_City", C);
                Cmd.CommandType = CommandType.StoredProcedure;
                Cmd.Parameters.AddWithValue("@ciname", Ciname);
                SqlDataReader R2 = Cmd.ExecuteReader();
                City cityobj = null;

                while (R2.Read())
                {
                    cityobj = new City();
                    cityobj.City_id = R2[0].ToString();
                    cityobj.City_Name = R2[1].ToString();
                    L.Add(cityobj);

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                C.Close();
            }
            return L;

        }
        public static int getcustid()
        {
            int c;
            try
            {
                C.Open();

                SqlCommand Cmd = new SqlCommand("Sp_GenerateVisaId", C);
                Cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader R = Cmd.ExecuteReader();
                R.Read();
                c = int.Parse(R[0].ToString()) + 1;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {

                C.Close();
            }
            return c;
        }

        public static string getCustId1(string ty)
        {
            int cid;
            try
            {
                C.Open();
                Cmd = new SqlCommand("sp_getCustid", C);
                Cmd.CommandType = CommandType.StoredProcedure;
                Cmd.Parameters.AddWithValue("@ty", ty);
                SqlDataReader R = Cmd.ExecuteReader();
                
                if (R.Read())
                {
                    cid = int.Parse(R[0].ToString()) + 1;
                }
                else
                {
                    cid = 1;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {

                C.Close();
            }
            return cid.ToString("0000");
        
        }
        public static string CheckLogin(string spname, List<SqlParameter> L)
        {
            string S = "NA";
            try
            {
                C.Open();
                SqlCommand Cmd = new SqlCommand("sp_login", C);
                Cmd.CommandType = CommandType.StoredProcedure;
                foreach (SqlParameter sp in L)
                {
                    Cmd.Parameters.Add(sp);
                }
                
                SqlDataReader R = Cmd.ExecuteReader();
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                C.Close();
            }
            return S;
        }
        public static string login(List<SqlParameter> l)
        {
            string s = null;
            try
            {
                C.Open();
                Cmd = new SqlCommand("sp_login", C);
                Cmd.CommandType = CommandType.StoredProcedure;
                foreach (SqlParameter sp in l)
                {
                    Cmd.Parameters.Add(sp);
                }
                SqlDataReader R = Cmd.ExecuteReader();
                //customer_booking_details cbd = new customer_booking_details();
                if (R.Read())
                {
                    // string s1 = R[1].ToString();
                    //cbd = new customer_booking_details(s1);
                    s = "0";
                }
                else
                {
                    s = "-1";
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                C.Close();
            }
            return s;
        }
       
        public static bool loginValidate(string spname, List<SqlParameter> L)
        {
            bool flag = false;
            try
            {
                C.Open();
                Cmd = new SqlCommand(spname, C);
                Cmd.CommandType = CommandType.StoredProcedure;
                foreach (SqlParameter P in L)
                {
                    Cmd.Parameters.Add(P);
                }
                SqlDataReader R = Cmd.ExecuteReader();
                if (R.Read())
                {
                    flag = true;

                }
            }
            catch (Exception E)
            {
                throw E;
            }
            finally
            {
                C.Close();
            }
            return flag;

        }
        public static List<Occupation> PopulateOccupation()
        {
            List<Occupation> L = new List<Occupation>();
            try
            {
                C.Open();
                Cmd = new SqlCommand("sp_getOccupation", C);
                Cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader R = Cmd.ExecuteReader();

                Occupation C1 = null;
                while (R.Read())
                {
                    C1 = new Occupation();
                    C1.Occupation_Id = (R[0].ToString());
                    C1.Occupation_name = R[1].ToString();
                    C1.Visa_Permit = double.Parse(R[2].ToString());
                    L.Add(C1);

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {


                C.Close();
            }

            return L;

        }

        public static string ExecuteInsert2(string spname, List<SqlParameter> l)
        {
            try
            {
                C.Open();
                Cmd = new SqlCommand(spname, C);
                Cmd.CommandType = CommandType.StoredProcedure;
                foreach (SqlParameter sp in l)
                {
                    Cmd.Parameters.Add(sp);
                }
                Cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                throw e;
            }
            finally{
            C.Close();
            }
            //string Visa_id = l[l.Count - 4].Value.ToString();
            //string User_id = l[l.Count - 8].Value.ToString();
            //DateTime dateofapplication = DateTime.Parse( l[l.Count - 5].Value.ToString());
            //DateTime dateofIssue = DateTime.Parse(l[l.Count - 3].Value.ToString());
            //string designation = l[l.Count - 6].Value.ToString();
            //int Cost = int.Parse(l[l.Count - 1].Value.ToString());
            //string s = "Visa_Id is " + Visa_id + " User_ID is " + User_id + " Occupation is " + designation+" Date of Application is "+dateofapplication+" Date of Issue "+dateofIssue+" Registration cost is "+Cost;
            return l[l.Count - 1].Value.ToString();
            
        }


    }
}

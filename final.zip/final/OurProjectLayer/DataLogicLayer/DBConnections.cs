﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLogicLayer
{
    public class DBConnections
    {
        public static string getConnection()
        {

            if (System.Web.HttpContext.Current.Session["Con"] == null)
            {
                string connStr = System.Configuration.ConfigurationManager.ConnectionStrings["Con"].ConnectionString;
                System.Web.HttpContext.Current.Session["Con"] = connStr;
            }

            return System.Web.HttpContext.Current.Session["Con"] as string;

        }
    }
}
